del 000 al 029 incluidos, estaba poco inspirado
