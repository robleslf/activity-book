#!/bin/bash

bienvenida() {
	cat << 'EOF'
              .---. .---. 
             :     : o   :    BIENVENIDO!!
         _..-:   o :     :-.._    /
     .-''  '  `---' `---' "   ``-.    
   .'   "   '  "  .    "  . '  "  `.  
  :   '.---.,,.,...,.,.,.,..---.  ' ;
  `. " `.                     .' " .'
   `.  '`.                   .' ' .'
    `.    `-._           _.-' "  .'  .----.
      `. "    '"--...--"'  . ' .'  .'  o   `.
      .'`-._'    " .     " _.-'`. :       o  :
    .'      ```--.....--'''    ' `:_ o       :
  .'    "     '         "     "   ; `.;";";";'
 ;         '       "       '     . ; .' ; ; ;
;     '         '       '   "    .'      .-'
'  "     "   '      "           "    _.-'
 
EOF
}

separador() {
	echo "* . ﹢ ˖ ✦ ¸ . ﹢ ° ¸. ° ˖ ･ ·̩ ｡ ☆ ﾟ ＊ "
	}

interruptor=0

comprobar() {
	separador
	if [[ $1 =~ ^[+]?[0-9]+$ ]]; then
		interruptor=1
	else
		echo "Debe introducir un número válido"
		separador
	fi
	}

pedir_numero() {
	while [[ $interruptor -eq 0 ]]; do
		read -p "Ingrese un número: " numero
		comprobar $numero
	done 
	}


factorializar() {
	pedir_numero
	factorial=$numero
	for (( i=$numero; i>1; i-- )); do
		siguiente_numero=$(( i - 1 ))
		factorial=$(( $factorial * $siguiente_numero ))
	done
	clear
	echo "El factorial de $numero es $factorial"
}

bienvenida
factorializar
