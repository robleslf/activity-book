#!/bin/bash

# Definir el directorio
DIRECTORY="/home/usuario/documentos"

# Contar archivos (no subdirectorios)
FILE_COUNT=$(find "$DIRECTORY" -maxdepth 1 -type f | wc -l)

echo "Hay $FILE_COUNT archivos en el directorio $DIRECTORY."
