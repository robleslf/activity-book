#!/bin/bash

# Definir el directorio de copias de seguridad
BACKUP_DIR="/home/usuario/copia_de_seguridad"

# Eliminar archivos de respaldo más antiguos que 30 días
find "$BACKUP_DIR" -type f -name "*.tar.gz" -mtime +30 -exec rm {} \;

# Verificar si la eliminación fue exitosa
if [ $? -eq 0 ]; then
    echo "Copia de seguridad antigua eliminada correctamente."
else
    echo "Error al eliminar las copias de seguridad antiguas."
fi
