#!/bin/bash

# Definir directorio de origen y destino
SOURCE_DIR="/home/usuario/datos"
BACKUP_DIR="/home/usuario/copia_de_seguridad"
DATE=$(date +%Y-%m-%d_%H-%M-%S)  # Formato de fecha para el archivo

# Crear directorio de copia de seguridad si no existe
mkdir -p "$BACKUP_DIR"

# Nombre del archivo de copia de seguridad
BACKUP_FILE="$BACKUP_DIR/backup_$DATE.tar.gz"

# Crear la copia de seguridad
tar -czvf "$BACKUP_FILE" -C "$SOURCE_DIR" .

# Verificar si la copia fue exitosa
if [ $? -eq 0 ]; then
    echo "Copia de seguridad creada exitosamente: $BACKUP_FILE"
else
    echo "Error al crear la copia de seguridad."
fi
