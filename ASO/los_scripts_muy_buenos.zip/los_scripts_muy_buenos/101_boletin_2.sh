#!/bin/bash

# 0. Crea un ficheiro chamado so.txt co seguinte contido.
echo -e "MX Linux\nDebian\nFedora\nAIX\nHP-UX\nUbuntu\nSuse linux\nRed Hat\nDebian\nubuntu\nelementary\nMint" > so.txt
echo "Ficheiro so.txt creado."

# 1. Ordena alfabéticamente o ficheiro so.txt
sort so.txt > so_sorted.txt
echo "so.txt ordenado alfabéticamente."

# 2. Ordena en orde inverso o ficheiro so.txt
sort -r so.txt > so_sorted_reverse.txt
echo "so.txt ordenado en orde inverso."

# 3. Ordena aleatoriamente o ficheiro so.txt.
shuf so.txt > so_sorted_random.txt
echo "so.txt ordenado aleatoriamente."

# 4. Elimina duplicados do ficheiro so.txt.
sort -u so.txt > so_no_duplicates.txt
echo "Duplicados eliminados de so.txt."

# 5. Crea o ficheiro months.txt co seguinte contido.
echo -e "July\nJanuary\nMarch\nOctober\nFebruary\nSeptember\nMay\nDecember\nFebruary\nJune\nAugust\nNovember\nApril" > months.txt
echo "Ficheiro months.txt creado."

# 6. Ordena o ficheiro months.txt por mes do ano.
sort -t$'\n' -k1 months.txt > months_sorted.txt
echo "months.txt ordenado por mes do ano."

# 7. Ordena aleatoriamente o ficheiro months.txt.
shuf months.txt > months_sorted_random.txt
echo "months.txt ordenado aleatoriamente."

# 8. Mostra o contido do ficheiro months.txt sen duplicados
sort -u months.txt
echo "Contido de months.txt sen duplicados."

# 9. Mostra o contido do ficheiro months.txt escrito do revés
tac months.txt
echo "Contido de months.txt escrito do revés."

# 10. A partir de months.txt, e dende a liña de comandos, crea un ficheiro chamado meses.txt con 2 campos: o número de mes e o nome do mes correspondente.
awk 'BEGIN{months="January February March April May June July August September October November December"} 
{print NR, $(months)}' months.txt > meses.txt
echo "Ficheiro meses.txt creado con número de mes e nome."

# 12. Ordena alfabéticamente o ficheiro meses.txt pola segunda columna.
sort -k2 meses.txt > meses_sorted_alphabetical.txt
echo "meses.txt ordenado alfabéticamente pola segunda columna."

# 13. Ordena o ficheiro meses.txt pola segunda columna alfabéticamente en orden decrecente e redirixe a saída a un novo ficheiro meses_ordenados.txt.
sort -k2,2r meses.txt > meses_ordenados.txt
echo "meses.txt ordenado alfabéticamente en orde decrecente pola segunda columna."

# 14. Ordena meses_ordenados.txt polo campo numérico en orde crecente.
sort -n -k1 meses_ordenados.txt > meses_ordenados_by_num.txt
echo "meses_ordenados.txt ordenado pola columna numérica en orde crecente."

# 15. Ordena meses_ordenados.txt polo campo numérico en orde decrecente.
sort -nr -k1 meses_ordenados.txt > meses_ordenados_by_num_reverse.txt
echo "meses_ordenados.txt ordenado pola columna numérica en orde decrecente."

# 16. Mostra a segunda linea do ficheiro meses_ordenados.txt.
sed -n '2p' meses_ordenados.txt
echo "Segunda liña de meses_ordenados.txt mostrada."

# 17. Divide o ficheiro meses.txt en trimestres xenerando ficheiros co prefixo trimestre_.
split -l 3 meses.txt trimestre_
echo "Ficheiros divididos en trimestres."

# 18. Mostra os 3 primeiros caracteres do mes do ficheiro meses.txt.
cut -c 1-3 meses.txt
echo "Tres primeiros caracteres dos meses mostrados."

# 19. Mostra o contido do ficheiro months en minúsculas.
cat months.txt | tr '[:upper:]' '[:lower:]'
echo "Contido de months.txt en minúsculas mostrado."

# 20. Mostra o contido de months.txt sen vocais e redirixe a saída para crear un novo arquivo months_abrev.txt.
cat months.txt | tr -d 'aeiouAEIOU' > months_abrev.txt
echo "Contido de months.txt sen vocais gardado en months_abrev.txt."

# 21. Repite o comando do apartado anterior para crear un novo arquivo months_abrev.txt.
cat months.txt | tr -d 'aeiouAEIOU' > months_abrev.txt
echo "Repetido: contido de months.txt sen vocais gardado en months_abrev.txt."

# 22. Verifica cun comando se o ficheiro months_abrev.txt está ordenado.
sort -c months_abrev.txt
echo "Verificación se months_abrev.txt está ordenado."

# 23. Mostra o contido de months.txt cambiando January por Xaneiro.
sed 's/January/Xaneiro/' months.txt
echo "January cambiado por Xaneiro en months.txt."

# 24. Usando o comando sed, mostra o contido de months.txt eliminado os meses que empecen por J.
sed '/^J/d' months.txt
echo "Meses que comezan con J eliminados de months.txt."

# 25. Repite o mesmo do exercicio anterior sen usar o comando sed.
grep -v '^J' months.txt
echo "Meses que comezan con J eliminados sen usar sed."

# 26. Usando o archivo months.txt mostra en maiúsculas a segunda R para os meses que teñen máis dunha r.
sed 's/\(.*r.*r.*\)/\U\1/' months.txt
echo "Maiúsculas na segunda R para meses con máis dunha r."

# 27. Mostra o número de caracteres en months.txt.
wc -m months.txt
echo "Número de caracteres en months.txt mostrado."

# 28. Mostra o arquivo months.txt se nas liñas 3 a 5.
sed -n '3,5p' months.txt
echo "Liñas 3 a 5 de months.txt mostradas."

# 29. Mostra o arquivo months.txt onde aparezca November duplicado.
sed '/November/{n;p}' months.txt
echo "November duplicado en months.txt mostrado."

# 30. Comprime o ficheiro months.txt.
gzip months.txt
echo "months.txt comprimido."

# 31. Se ter que descomprimilo, mostra o contido do ficheiro xenerado no apartado anterior.
gunzip -c months.txt.gz
echo "Contido de months.txt descomprimido mostrado."

# 32. Descomprime o ficheiro que comprimiches no apartado anterior.
gunzip months.txt.gz
echo "months.txt descomprimido."

# 33. Repite o anterior, pero redirixe a saída a un novo ficheiro chamado months_descomprimido.txt.
gunzip -c months.txt.gz > months_descomprimido.txt
echo "months.txt descomprimido e gardado en months_descomprimido.txt."

# 34. Comproba se months.txt e months_descomprimido.txt son o mesmo archivo usando un algoritmo de verificación de integridade.
diff months.txt months_descomprimido.txt
echo "Verificación de integridade entre months.txt e months_descomprimido.txt."
