#!/bin/bash

saudar() {
	echo "Hola, mun...digo, $1"
}

saudar $(whoami)
