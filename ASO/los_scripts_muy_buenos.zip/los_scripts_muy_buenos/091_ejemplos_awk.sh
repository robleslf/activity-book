#!/bin/bash

# Creamos un archivo de ejemplo
cat <<EOF > ejemplo.txt
Juan,23,Ingeniero
Maria,35,Abogada
Pedro,30,Programador
Elena,40,Arquitecta
Carlos,28,Diseñador
EOF

# Mostrar el contenido del archivo
echo "Contenido del archivo 'ejemplo.txt':"
cat ejemplo.txt
echo

# Uso 1: Imprimir las columnas específicas de un archivo
echo "Uso 1: Imprimir la primera y segunda columna (nombre y edad):"
awk -F, '{print $1, $2}' ejemplo.txt
echo

# Uso 2: Filtrar líneas basadas en un valor específico (edad mayor de 30)
echo "Uso 2: Filtrar usuarios con edad mayor de 30:"
awk -F, '$2 > 30 {print $1, $2}' ejemplo.txt
echo

# Uso 3: Realizar un cálculo (por ejemplo, calcular el promedio de edad)
echo "Uso 3: Calcular el promedio de edad de todos los usuarios:"
awk -F, '{sum += $2; count++} END {print "Promedio de edad:", sum/count}' ejemplo.txt
echo

# Uso 4: Cambiar el formato de salida (mostrar un mensaje personalizado)
echo "Uso 4: Cambiar formato de salida con texto personalizado:"
awk -F, '{print "El usuario " $1 " tiene " $2 " años y es " $3 "."}' ejemplo.txt
echo

# Uso 5: Imprimir líneas con un número específico de campos (en este caso 3)
echo "Uso 5: Imprimir líneas con 3 campos:"
awk -F, 'NF == 3 {print $0}' ejemplo.txt
echo

# Uso 6: Contar el número de líneas que contienen la palabra 'Programador'
echo "Uso 6: Contar líneas que contienen 'Programador':"
awk -F, '/Programador/ {count++} END {print "Número de Programadores:", count}' ejemplo.txt
echo

# Uso 7: Reemplazar texto en un archivo (reemplazar 'Programador' por 'Desarrollador')
echo "Uso 7: Reemplazar 'Programador' por 'Desarrollador':"
awk -F, '{gsub("Programador", "Desarrollador"); print $0}' ejemplo.txt
echo

# Eliminar el archivo de ejemplo después de ejecutar el script
rm ejemplo.txt
