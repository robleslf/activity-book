#!/bin/bash

# Definir archivo de contador
contador="/tmp/contador_script.txt"

# Verificar si el archivo existe
if [ ! -f "$contador" ]; then
    # Si no existe, crearlo e inicializar el contador en 1
    echo "1" > "$contador"
else
    # Leer el contador, incrementarlo y guardar el nuevo valor
    count=$(cat "$contador")
    count=$((count + 1))
    echo "$count" > "$contador"
fi

echo "Este script ha sido ejecutado $count veces."
