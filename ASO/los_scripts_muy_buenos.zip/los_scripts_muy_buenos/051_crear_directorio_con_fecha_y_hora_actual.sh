#!/bin/bash

# Crear carpeta con la fecha y hora actual
DIR_NAME=$(date +'%Y-%m-%d_%H-%M-%S')
mkdir "/home/usuario/$DIR_NAME"

echo "Carpeta $DIR_NAME creada exitosamente."
