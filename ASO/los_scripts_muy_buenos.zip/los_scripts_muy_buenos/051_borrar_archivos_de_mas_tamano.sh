#!/bin/bash

# Definir directorio y tamaño mínimo
DIRECTORY="/home/usuario/descargas"
SIZE="100M"

# Buscar y eliminar archivos mayores al tamaño especificado
find "$DIRECTORY" -type f -size +$SIZE -exec rm -f {} \;

echo "Archivos mayores a $SIZE han sido eliminados."
