#!/bin/bash

# 1. Cambia o nome da túa máquina virtual de maneira permanente indicando o nome do posto na aula (por exemplo, para o posto 08: maquina08).
# Cambiar o nome de host de forma permanente
sudo hostnamectl set-hostname maquina08
echo "Nome de máquina cambiado a: $(hostname)"

# 2. Busca cal é o target por defecto e lista todos os targets do sistema.
# Comprobar o target por defecto e listar todos os targets
DEFAULT_TARGET=$(systemctl get-default)
echo "O target por defecto é: $DEFAULT_TARGET"
echo "Lista de todos os targets dispoñibles no sistema:"
systemctl list-units --type=target

# 3. Cambia ao target multi-user e comproba se hai algunha diferenza nos procesos que están correndo.
# Cambiar ao target multi-user
sudo systemctl isolate multi-user.target
echo "Cambiado ao target multi-user. Lista de procesos en execución:"
ps aux

# 4. Cambia o modo por defecto a multi-user. Comproba que arrinca nese modo e volve deixar o target que tiña orixinalmente.
# Cambiar o modo por defecto ao target multi-user
sudo systemctl set-default multi-user.target
echo "O modo por defecto foi cambiado a multi-user."
echo "Comprobando se arrinca en modo multi-user:"
systemctl get-default

# Volver ao target orixinal (normalmente graphical.target)
sudo systemctl set-default graphical.target
echo "O modo por defecto foi restaurado ao seu estado orixinal."

# 5. Deshabilita o servizo "cron" e comproba que ese servizo xa non é unha dependencia do target.
# Deshabilitar o servizo cron
sudo systemctl stop cron
sudo systemctl disable cron
echo "Servizo cron deshabilitado."
echo "Verificando que o servizo cron xa non é unha dependencia do target:"
systemctl list-dependencies multi-user.target | grep cron

# 6. Comproba se o servizo está a correr e se é así deteno.
# Comprobar se o servizo cron está a correr
if systemctl is-active --quiet cron; then
    echo "O servizo cron está en execución. Deténdoo agora."
    sudo systemctl stop cron
else
    echo "O servizo cron non está en execución."
fi

# 7. Volve habilitar o servizo "cron".
# Habilitar o servizo cron
sudo systemctl enable cron
echo "Servizo cron habilitado."

# 8. Usa o comando lspci para listar todos os dispositivos no teu sistema. Usa o modo detallado e asegúrate de que se inclúa toda a información de IRQ ou dirección.
# Listar todos os dispositivos PCI no sistema con detalle
echo "Listando todos os dispositivos PCI con modo detallado:"
lspci -vv

# 9. Dende a liña de comando, enumera todos os módulos activados actualmente no sistema. Determina se o teu sistema ten un módulo habilitado para o cdrom. Se é así, cal é o nome?
# Listar todos os módulos cargados
echo "Listando todos os módulos cargados no sistema:"
lsmod
# Comprobar se o módulo para CD-ROM está cargado
echo "Comprobando si hai un módulo cargado para CD-ROM:"
lsmod | grep cdrom

# 10. Usando algúns dos comandos que aprendemos ata o de agora, atopa un módulo de sistema de arquivos que estea CARGADO pero que NON se estea usando. Identifica o nome do seu módulo.
# Buscar un módulo de sistema de arquivos cargado pero non en uso
echo "Buscando módulos de sistema de arquivos cargados pero non en uso:"
lsmod | grep -i fs
# (Reemplaza con o nome específico do módulo que non se estea a usar)

# 11. Agora desinstala ese módulo e verifica que xa non está cargado no kernel. Enumera os pasos para desinstalar o módulo e como verificaches que xa non está cargado.
# Desinstalar o módulo
MÓDULO="nombre_del_módulo"  # Substitúeo co nome do módulo a desinstalar
sudo rmmod $MÓDULO
echo "Módulo $MÓDULO desinstalado."

# Verificar que o módulo xa non está cargado
lsmod | grep $MÓDULO
if [ $? -ne 0 ]; then
    echo "O módulo $MÓDULO xa non está cargado no kernel."
else
    echo "O módulo $MÓDULO segue cargado."
fi

# 12. Sen usar modprobe, volve a cargar e verifica o módulo que se eliminou recentemente. Enumera os pasos para cargar o módulo e como verificaches que agora se cargou.
# Volver cargar o módulo
sudo insmod /lib/modules/$(uname -r)/kernel/fs/$MÓDULO.ko
echo "Módulo $MÓDULO cargado novamente."

# Verificar que o módulo está cargado
lsmod | grep $MÓDULO
if [ $? -eq 0 ]; then
    echo "O módulo $MÓDULO foi cargado correctamente."
else
    echo "Non foi posible cargar o módulo $MÓDULO."
fi
