#!/bin/bash

# Nombre del fichero
fichero="090_usuarios.txt"  # Cambia el nombre si es necesario

# Inicializar las variables
edad_mas_baja=9999  # Asignamos un valor muy alto para comparar
edad_mas_alta=-1    # Asignamos un valor muy bajo para comparar
persona_mas_baja=""
persona_mas_alta=""

# Leer el fichero línea por línea
while IFS=',' read -r nombre edad; do
    # Verificar si la edad es un número
    if [[ "$edad" =~ ^[0-9]+$ ]]; then
        # Comprobar si es la edad más baja
        if [[ "$edad" -lt "$edad_mas_baja" ]]; then
            edad_mas_baja="$edad"
            persona_mas_baja="$nombre"
        fi

        # Comprobar si es la edad más alta
        if [[ "$edad" -gt "$edad_mas_alta" ]]; then
            edad_mas_alta="$edad"
            persona_mas_alta="$nombre"
        fi
    else
        echo "Advertencia: Línea con edad no válida ($nombre, $edad)"
    fi
done < "$fichero"

# Mostrar los resultados
echo "La persona con la edad más baja es: $persona_mas_baja, con $edad_mas_baja años."
echo "La persona con la edad más alta es: $persona_mas_alta, con $edad_mas_alta años."

