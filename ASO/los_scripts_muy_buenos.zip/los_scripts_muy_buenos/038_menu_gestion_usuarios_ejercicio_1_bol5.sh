#!/bin/bash

# Función para mostrar el menú
mostrar_menu() {
    clear
    echo "-------------------------------------------"
    echo "             XESTION DE USUARIOS           "
    echo "-------------------------------------------"
    echo "   1) Crear usuario(s) por consola"
    echo "   2) Eliminar usuario(s) por consola"
    echo "   3) Crear usuarios a partir de ficheiro"
    echo "   4) Eliminar usuarios a partir de ficheiro"
    echo "   5) Axuda"
    echo "   6) Saída"
    echo "-------------------------------------------"
    echo -n "Seleccione unha opción: "
}

# Función para validar nombres de usuarios
validar_usuario() {
    local usuario="$1"
    [[ "$usuario" =~ ^[a-zA-Z0-9_-]+$ ]]  # Permite letras, números, guiones y guiones bajos
}

# Función para verificar si un usuario existe en el sistema
existe_usuario() {
    id "$1" > /dev/null 2>&1
}

# Función para crear usuarios desde un array
crear_usuarios() {
    local usuarios=("$@")
    for usuario in "${usuarios[@]}"; do
        if validar_usuario "$usuario"; then
            if existe_usuario "$usuario"; then
                echo "O usuario '$usuario' xa existe."
            else
                sudo useradd -m -s /bin/bash "$usuario" && echo "$usuario:$usuario" | sudo chpasswd
                echo "Usuario '$usuario' creado con éxito."
            fi
        else
            echo "Nome do usuario '$usuario' non é válido."
        fi
    done
}

# Función para eliminar usuarios desde un array
eliminar_usuarios() {
    local usuarios=("$@")
    for usuario in "${usuarios[@]}"; do
        if validar_usuario "$usuario"; then
            if existe_usuario "$usuario"; then
                sudo userdel -r "$usuario" && echo "Usuario '$usuario' eliminado con éxito."
            else
                echo "O usuario '$usuario' non existe."
            fi
        else
            echo "Nome do usuario '$usuario' non é válido."
        fi
    done
}

# Función para procesar usuarios desde un fichero
procesar_ficheiro() {
    local ficheiro="$1"
    local accion="$2"  # "crear" ou "eliminar"

    if [[ ! -f "$ficheiro" ]]; then
        echo "Erro: O ficheiro '$ficheiro' non existe."
        return 1
    fi

    while IFS='|' read -r login nome grupo; do
        if [[ -z "$login" || -z "$nome" || -z "$grupo" ]]; then
            echo "Erro: Entrada inválida no ficheiro. Campos: login|nome|grupo"
            continue
        fi

        if [[ "$accion" == "crear" ]]; then
            if validar_usuario "$login"; then
                if ! getent group "$grupo" > /dev/null; then
                    echo "O grupo '$grupo' non existe. Creando grupo..."
                    sudo groupadd "$grupo"
                fi
                if existe_usuario "$login"; then
                    echo "O usuario '$login' xa existe."
                else
                    sudo useradd -m -s /bin/bash -g "$grupo" -c "$nome" "$login" && echo "$login:$login" | sudo chpasswd
                    echo "Usuario '$login' creado con éxito."
                fi
            else
                echo "Nome do usuario '$login' non é válido."
            fi
        elif [[ "$accion" == "eliminar" ]]; then
            if validar_usuario "$login"; then
                if existe_usuario "$login"; then
                    sudo userdel -r "$login" && echo "Usuario '$login' eliminado con éxito."
                else
                    echo "O usuario '$login' non existe."
                fi
            else
                echo "Nome do usuario '$login' non é válido."
            fi
        else
            echo "Acción descoñecida: $accion"
        fi
    done < "$ficheiro"
}

# Función para mostrar a axuda
mostrar_axuda() {
    echo "Axuda:
    1) Crear usuario(s) por consola: Permite crear un ou máis usuarios ingresados por teclado.
    2) Eliminar usuario(s) por consola: Permite eliminar un ou máis usuarios ingresados por teclado.
    3) Crear usuarios a partir de ficheiro: Crea usuarios listados nun ficheiro (formato: login|nome|grupo).
    4) Eliminar usuarios a partir de ficheiro: Elimina usuarios listados nun ficheiro (formato: login|nome|grupo).
    5) Axuda: Mostra esta información.
    6) Saída: Finaliza o programa."
}

# Programa principal
while true; do
    mostrar_menu
    read opcion

    case "$opcion" in
        1)
            echo -n "Introduce os nomes dos usuarios separados por espazo: "
            read -a usuarios
            crear_usuarios "${usuarios[@]}"
            ;;
        2)
            echo -n "Introduce os nomes dos usuarios separados por espazo: "
            read -a usuarios
            eliminar_usuarios "${usuarios[@]}"
            ;;
        3)
            echo -n "Introduce o nome do ficheiro cos usuarios a crear: "
            read ficheiro
            procesar_ficheiro "$ficheiro" "crear"
            ;;
        4)
            echo -n "Introduce o nome do ficheiro cos usuarios a eliminar: "
            read ficheiro
            procesar_ficheiro "$ficheiro" "eliminar"
            ;;
        5)
            mostrar_axuda
            ;;
        6)
            echo "Saíndo do programa. Ata logo!"
            break
            ;;
        *)
            echo "Opción non válida. Por favor, tente de novo."
            ;;
    esac
    echo -n "Prema Enter para continuar..."
    read
done
