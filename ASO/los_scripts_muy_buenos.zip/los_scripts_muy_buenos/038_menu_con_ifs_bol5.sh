#!/bin/bash

# Función para validar nombres de usuarios y grupos
validar_nombre() {
    local nombre="$1"
    [[ "$nombre" =~ ^[a-zA-Z0-9_-]+$ ]]  # Permite letras, números, guiones y guiones bajos
}

# Función para verificar si un grupo existe en el sistema
existe_grupo() {
    getent group "$1" > /dev/null 2>&1
}

# Función para verificar si un usuario existe en el sistema
existe_usuario() {
    id "$1" > /dev/null 2>&1
}

# Función para crear grupos y usuarios a partir del archivo
crear_usuarios_y_grupos() {
    local fichero="$1"

    if [[ ! -f "$fichero" ]]; then
        echo "Erro: O ficheiro '$fichero' non existe."
        return 1
    fi

    while IFS='|' read -r nombre apelido1 apelido2 asignatura; do
        # Eliminar posibles espacios extra
        nombre=$(echo "$nombre" | xargs)
        apelido1=$(echo "$apelido1" | xargs)
        apelido2=$(echo "$apelido2" | xargs)
        asignatura=$(echo "$asignatura" | xargs)

        if [[ -z "$nombre" || -z "$apelido1" || -z "$apelido2" || -z "$asignatura" ]]; then
            echo "Datos incompletos en a liña '$nombre|$apelido1|$apelido2|$asignatura'. Saltando."
            continue
        fi

        # Crear el grupo (si no existe)
        grupo=$(echo "$asignatura" | tr '[:upper:]' '[:lower:]')  # Convertir a minúsculas
        if ! existe_grupo "$grupo"; then
            sudo groupadd "$grupo"
            echo "Grupo '$grupo' creado con éxito."
        else
            echo "O grupo '$grupo' xa existe."
        fi

        # Crear el login del usuario (primer letra de nombre + 3 primeras letras de apellido1 + 3 primeras de apellido2)
        login=$(echo "$nombre" | cut -c1 | tr '[:upper:]' '[:lower:]')  # Primer letra del nombre en minúscula
        login+=$(echo "$apelido1" | cut -c1-3 | tr '[:upper:]' '[:lower:]')  # Primeras 3 letras de apellido1 en minúscula
        login+=$(echo "$apelido2" | cut -c1-3 | tr '[:upper:]' '[:lower:]')  # Primeras 3 letras de apellido2 en minúscula

        # Verificar si el usuario ya existe
        if existe_usuario "$login"; then
            echo "O usuario '$login' xa existe."
        else
            # Crear el usuario y asignarle el HOME y clave (idénticos al login)
            sudo useradd -m -s /bin/bash -g "$grupo" -c "$nombre $apelido1 $apelido2" "$login" && echo "$login:$login" | sudo chpasswd
            echo "Usuario '$login' creado con éxito."
        fi

    done < "$fichero"
}

# Llamar a la función principal con el nombre del archivo
fichero="alumnado.txt"  # Aquí pones la ruta al archivo si es necesario

crear_usuarios_y_grupos "$fichero"
