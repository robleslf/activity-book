#!/bin/bash

# Definir directorio y archivo comprimido
SOURCE_DIR="/home/usuario/datos"
BACKUP_FILE="/home/usuario/backup_datos.tar.gz"

# Comprimir el directorio
tar -czf "$BACKUP_FILE" -C "$SOURCE_DIR" .

# Verificar si la compresión fue exitosa
if [ $? -eq 0 ]; then
    echo "Directorio comprimido exitosamente: $BACKUP_FILE"
else
    echo "Error al comprimir el directorio."
fi
