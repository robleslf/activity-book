#!/bin/bash

# Nombre del grupo a verificar
grupo="nombre_del_grupo"

# Verificar si el grupo existe
if getent group "$grupo" > /dev/null 2>&1; then
    echo "El grupo '$grupo' existe."

    # Obtener los usuarios que pertenecen a ese grupo
    # El comando 'getent group' devuelve la línea del grupo en el formato: grupo:x:GID:usuario1,usuario2,...
    usuarios=$(getent group "$grupo" | cut -d: -f4)

    if [ -z "$usuarios" ]; then
        echo "El grupo '$grupo' no tiene usuarios asignados."
    else
        echo "Usuarios del grupo '$grupo': $usuarios"
    fi
else
    echo "El grupo '$grupo' no existe."
fi
