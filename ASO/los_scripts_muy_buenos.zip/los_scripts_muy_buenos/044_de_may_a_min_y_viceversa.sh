#!/bin/bash

# Pedir al usuario que elija una opción
echo "Selecciona una opción:"
echo "1. Convertir a mayúsculas"
echo "2. Convertir a minúsculas"
read -p "Opción (1 o 2): " opcion
read -p "Introduce el texto: " texto

# Ejecutar según la opción
if [ "$opcion" -eq 1 ]; then
    echo "$texto" | tr 'a-z' 'A-Z'
elif [ "$opcion" -eq 2 ]; then
    echo "$texto" | tr 'A-Z' 'a-z'
else
    echo "Opción no válida."
fi
