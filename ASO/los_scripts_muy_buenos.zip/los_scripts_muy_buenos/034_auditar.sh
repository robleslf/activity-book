#!/bin/bash

separador(){
	echo "________________________"
}

usuarios_conectados() {
	separador
	echo "Usuarios conectados: "
	who
	separador
}

espazo_en_disco() {
	separador
	echo "Espacio en disco: "
	df
	separador
}

opcion_invalida() {
	separador
	echo "Por favor, elija 0, 1 o 2."
	separador
}

menu() {
	while true; do
		echo "Elija una opción, por favor:"
		echo "0) Fin"
		echo "1) Mostrar a lista de usuarios conectados"
		echo "2) Mostrar o espacio en disco"
		read -p ":" opcion

		case $opcion in
			0) separador; echo "Chao pescao"; break ;;
			1) usuarios_conectados ;;
			2) espazo_en_disco ;;
			*) opcion_invalida ;;
		esac
	done
}

menu
