#!/bin/bash

# Definir archivo a descomprimir y directorio de destino
TAR_FILE="/home/usuario/backup_datos.tar.gz"
DEST_DIR="/home/usuario/restauracion"

# Descomprimir el archivo
tar -xzvf "$TAR_FILE" -C "$DEST_DIR"

# Verificar si la descompresión fue exitosa
if [ $? -eq 0 ]; then
    echo "Archivo descomprimido exitosamente en: $DEST_DIR"
else
    echo "Error al descomprimir el archivo."
fi
