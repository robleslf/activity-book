#!/bin/bash

# 1. Mostra os ficheiros do directorio /etc que teñan 3 letras seguido da extensión .conf.
echo "1. Ficheiros do directorio /etc con 3 letras e extensión .conf:"
ls /etc | grep -E '^...\.conf$'

# 2. Mostra os ficheiros do directorio /etc que empecen por U ou V.
echo "2. Ficheiros que empecen por U ou V:"
ls /etc | grep -E '^[UV]'

# 3. Mostra o último ficheiro que se editou no directorio /etc.
echo "3. Último ficheiro editado no directorio /etc:"
ls -lt /etc | head -n 1

# 4. Mostra os ficheiros do directorio /etc mostrando unha sola entrada por linea.
echo "4. Ficheiros do directorio /etc, unha entrada por liña:"
ls -1 /etc

# 5. Fai o mesmo que no paso anterior, pero mostra tamén o inodo de cada ficheiro.
echo "5. Ficheiros do directorio /etc con inodo:"
ls -i /etc

# 6. Mostra o contido do directorio /etc ordenado por tamaño.
echo "6. Contido do directorio /etc ordenado por tamaño:"
ls -lS /etc

# 7. Mostra os arquivos do directorio /etc organizado alfabéticamente pola extensión dos ficheiros.
echo "7. Arquivos do directorio /etc ordenados por extensión alfabéticamente:"
ls -lX /etc

# 8. Cámbiate ó directorio /etc e lista solo os directorios que contén.
echo "8. Directorios no directorio /etc:"
cd /etc && ls -d */

# 9. Repite o apartado anterior, pero indicando a ruta absoluta.
echo "9. Directorios no directorio /etc con ruta absoluta:"
ls -d $PWD/*/

# 10. Mostra o contido do directorio /etc ordenado por hora de modificación (os máis recentes ó final).
echo "10. Contido do directorio /etc ordenado por hora de modificación:"
ls -lt /etc

# 11. Mostra a estrutura do directorios de /etc.
echo "11. Estrutura do directorio /etc:"
tree /etc

# 12. Cámbiate ó teu directorio HOME e mostra únicamente os ficheiros ocultos.
echo "12. Ficheiros ocultos no directorio HOME:"
cd ~ && ls -d .*

# 13. Mostra únicamente os directorios ocultos do teu HOME.
echo "13. Directorios ocultos no directorio HOME:"
ls -d ~/.**/

# 14. Crea no teu HOME a carpeta laboratorio, e dentro dela crea:
# - un directorio: “directorio”
# - un ficheiro normal que incluía o nome da máquina: ”ficheiro”
# - un archivo de enlace ó ficheiro anterior: ”enlace”
# - un archivo executable: “executable”
echo "14. Creando estructura de directorios e ficheiros:"
mkdir -p ~/laboratorio/directorio
echo "$(hostname)" > ~/laboratorio/ficheiro
ln -s ~/laboratorio/ficheiro ~/laboratorio/enlace
touch ~/laboratorio/executable
chmod +x ~/laboratorio/executable

# 15. Lista o contido da carpeta laboratorio mostrando o tipo de archivo.
echo "15. Contido da carpeta laboratorio co tipo de arquivo:"
ls -l ~/laboratorio

# 16. Mostra o contido da carpeta laboratorio clasificando con cores o tipo de archivo.
echo "16. Contido da carpeta laboratorio con clasificación por cores:"
ls --color=auto ~/laboratorio

# 17. Crea un alias chamado ll, que faga un listado longo, que inclúa os arquivos ocultos e que mostre as cores según o tipo de arquivo. Próbao para ver o resultado.
echo "17. Creando alias 'll':"
alias ll='ls -la --color=auto'
ll

# 18. Crea outro alias para que se pida confirmación antes de borrar un arquivo ou directorio.
echo "18. Creando alias para pedir confirmación ao borrar arquivos:"
alias rm='rm -i'

# 19. Mostra o contido do arquivo ”ficheiro” que creaches nun paso anterior. Elimínao e comproba que pide confirmación.
echo "19. Mostrando o contido do ficheiro 'ficheiro' e eliminándoo:"
cat ~/laboratorio/ficheiro
rm ~/laboratorio/ficheiro

# 20. Mostra os alias que tes configurados.
echo "20. Alias configurados:"
alias

# 21. Borra o alias ll que configuramos nun paso anterior.
echo "21. Eliminando alias 'll':"
unalias ll

# 22. Mostra o contido do ficheiro enlace “enlace” que creaches na carpeta laboratorio. Explica o resultado.
echo "22. Contido do enlace 'enlace':"
cat ~/laboratorio/enlace

# 23. Elimina o enlace “enlace” sen usar rm.
echo "23. Eliminando o enlace 'enlace' sen usar rm:"
unlink ~/laboratorio/enlace

# 24. Crea un novo arquivo “ficheiro2” e que teña a data do primeiro día deste mes ó mediodía.
echo "24. Creando 'ficheiro2' con data do primeiro día do mes:"
touch -d "$(date +'%Y-%m-01') 12:00:00" ~/laboratorio/ficheiro2

# 25. Asígnalle agora a data que teña o /etc/passwd.
echo "25. Asignando a data de /etc/passwd a 'ficheiro2':"
touch -r /etc/passwd ~/laboratorio/ficheiro2

# 26. Busca no ficheiro /etc/passwd as liñas que teñan o patrón “Time”.
echo "26. Buscando 'Time' no ficheiro /etc/passwd:"
grep "Time" /etc/passwd

# 27. Repite a búsqueda pero que non distinga entre maísculas ou minúsculas.
echo "27. Buscando 'Time' sen distinguir entre maiúsculas ou minúsculas:"
grep -i "Time" /etc/passwd

# 28. Busca en /etc/passwd a palabra “nobody” e mostra esa liña e as 5 seguintes.
echo "28. Buscando 'nobody' en /etc/passwd e mostrando as 5 seguintes:"
grep -A 5 "nobody" /etc/passwd

# 29. Repite o mesmo, pero mostra ademais desa liña, as 5 anteriores e as 5 posteriores.
echo "29. Buscando 'nobody' en /etc/passwd e mostrando 5 liñas anteriores e posteriores:"
grep -B 5 -A 5 "nobody" /etc/passwd

# 30. Repite o mesmo, pero non mostres a liña 'nobody'. Mostra únicamente as 5 anteriores e as 5 posteriores.
echo "30. Mostrando 5 liñas antes e 5 despois de 'nobody', pero non mostrando 'nobody':"
grep -B 5 -A 5 "nobody" /etc/passwd | grep -v "nobody"

# 31. Mostra as liñas do ficheiro /etc/passwd nas que aparece a palabra system e número de liña na que aparece.
echo "31. Buscando 'system' en /etc/passwd e mostrando número de liña:"
grep -n "system" /etc/passwd

# 32. Repite o exercicio anterior sen usar o comando sed.
echo "32. Buscando 'system' en /etc/passwd sen usar sed:"
grep -n "system" /etc/passwd

# 33. Busca a palabra nfs en todos os ficheiros con extensión .conf no directorio /etc.
echo "33. Buscando 'nfs' en ficheiros .conf no directorio /etc:"
grep "nfs" /etc/*.conf

# 34. Repite a búsqueda pero resaltando en cor a palabra buscada.
echo "34. Buscando 'nfs' en ficheiros .conf no directorio /etc con resaltado:"
grep --color=auto "nfs" /etc/*.conf

# 35. Repite a búsqueda pero mostra únicamente a palabra buscada.
echo "35. Buscando 'nfs' e mostrando só a palabra:"
grep -o "nfs" /etc/*.conf

# 36. Repite a búsqueda da palabra nfs en todos os ficheiros con extensión .conf no directorio /etc., pero elimina as liñas que sexan comentarios.
echo "36. Buscando 'nfs' en ficheiros .conf no directorio /etc e eliminando liñas de comentarios:"
grep "nfs" /etc/*.conf | grep -v "^#"

# 37. Repite a búsqueda anterior, pero mostra únicamente o nome dos arquivos.
echo "37. Buscando 'nfs' en ficheiros .conf no directorio /etc e mostrando só os nomes dos arquivos:"
grep -l "nfs" /etc/*.conf

# 38. Conta os ficheiros con extensión .conf no directorio /etc que non teñan a palabra system.
echo "38. Contando ficheiros .conf que non teñan a palabra 'system' no directorio /etc:"
grep -L "system" /etc/*.conf | wc -l

# 39. Fai unha búsqueda da palabras “nfs” e “keys” en todos os ficheiros con extensión .conf no directorio /etc.
echo "39. Buscando 'nfs' e 'keys' en ficheiros .conf no directorio /etc:"
grep -e "nfs" -e "keys" /etc/*.conf

# 40. Repite a búsqueda usando a versión extendida do comando grep.
echo "40. Buscando 'nfs' e 'keys' en ficheiros .conf no directorio /etc usando grep -E:"
grep -E "nfs|keys" /etc/*.conf

# 41. Fai unha búsqueda en todos os ficheiros con extensión .conf no directorio /etc. das liñas que rematen coa palabra kernel.
echo "41. Buscando liñas que rematen con 'kernel' en ficheiros .conf no directorio /etc:"
grep "kernel$" /etc/*.conf

# 42. Mostra as liñas do ficheiro /etc/fstab que non sexan comentarios e que teñan caracteres numéricos.
echo "42. Liñas do ficheiro /etc/fstab sen comentarios e que teñen caracteres numéricos:"
grep -v "^#" /etc/fstab | grep "[0-9]"

# 43. Crea a seguinte estrutura de directorios no /tmp da maneira máis concisa posible.
echo "43. Creando estrutura de directorios no /tmp:"
mkdir -p /tmp/DIR/DIRA/D1 /tmp/DIR/DIRA/D2 /tmp/DIR/DIRA/D3 /tmp/DIR/DIRB/Da /tmp/DIR/DIRB/Db

# 44. Crea os seguintes ficheiros baleiros e visualiza cun comando que estean no directorio adecuado.
echo "44. Creando ficheiros baleiros no directorio adecuado:"
touch /tmp/DIR/DIRA/D1/f1.txt /tmp/DIR/DIRA/D3/f2.vacio /tmp/DIR/f.zip /tmp/DIR/DIRB/Da/f3.xxx
ls /tmp/DIR/DIRA/D1 /tmp/DIR/DIRA/D3 /tmp/DIR/DIRB/Da

# 45. Copia o contido de /etc/services en Db/services.
echo "45. Copiando o contido de /etc/services en Db/services:"
cp /etc/services /tmp/DIR/DIRB/Db/services

# 46. Comprime en formato gzip e nivel de compresión 8 o ficheiro Db/services.
echo "46. Comprimindo o ficheiro Db/services en gzip:"
gzip -8 /tmp/DIR/DIRB/Db/services

# 47. Descomprime o ficheiro anterior dentro de D2 poñéndolle de nome copia.services.
echo "47. Descomprimindo Db/services en D2 co nome copia.services:"
gzip -d /tmp/DIR/DIRB/Db/services.gz -c > /tmp/DIR/DIRA/D2/copia.services

# 48. Empaqueta (sen comprimir) toda a árbore anterior (/tmp/DIR) no ficheiro paquete.tar e gárdao en /tmp.
echo "48. Empaquetando toda a árbore no ficheiro paquete.tar:"
tar -cf /tmp/paquete.tar -C /tmp DIR

# 49. Le o contido do paquete.tar.
echo "49. Lendo o contido do paquete.tar:"
tar -tf /tmp/paquete.tar

# 50. Nunha sola execución, empaqueta e comprime toda a árbore /tmp/DIR nun arquivo chamado paquete.tar.gz e gárdao en /tmp.
echo "50. Empaquetando e comprimindo a árbore /tmp/DIR en paquete.tar.gz:"
tar -czf /tmp/paquete.tar.gz -C /tmp DIR

# 51. Le o contido do ficheiro xenerado.
echo "51. Lendo o contido do ficheiro paquete.tar.gz:"
tar -tzf /tmp/paquete.tar.gz

# 52. Obtén do paquete anterior comprimido o ficheiro services.gz e deixao no directorio actual de traballo.
echo "52. Extraendo services.gz de paquete.tar.gz no directorio actual:"
tar -xzf /tmp/paquete.tar.gz --wildcards '*/services.gz'

# 53. Empaqueta e comprime nun ficheiro chamado paquete_excluido.tar.gz o contido do directorio /tmp/DIR pero excluíndo os ficheiros services (todos) e f3.xxx.
echo "53. Empaquetando e comprimindo excluíndo ficheiros específicos:"
tar --exclude='*/services' --exclude='*/f3.xxx' -czf /tmp/paquete_excluido.tar.gz -C /tmp DIR

# 54. Le o ficheiro anterior e comproba que non contén os ficheiros eliminados.
echo "54. Lendo paquete_excluido.tar.gz para comprobar que non contén services e f3.xxx:"
tar -tzf /tmp/paquete_excluido.tar.gz
