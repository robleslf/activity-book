#!/bin/bash

programa_principal() {
    echo "Benvido"
    echo "0) Fin"
    echo "1) Listar usuarios do sistema"
    echo "2) Comprobar se existe un usuario no sistema"
    echo "3) Engadir un usuario no sistema"
    echo "4) Eliminar un usuario no sistema"
    echo "5) Axuda"
    read -p "Elixe unha opción: " opcion

    case "$opcion" in
        0) sair ;;
        1) listar ;;
        2) comprobar ;;
        3) engadir ;;
        4) eliminar ;;
        5) axuda ;;
        *) echo "Opción inválida. Inténtao de novo." ;;
    esac
}

separador() {
    echo "* . ﹢ ˖ ✦ ¸ . ﹢ ° ¸. ° ˖ ･ ·̩ ｡ ☆ ﾟ ＊ ¸* . ﹢ ˖ ✦ ¸ . ﹢ ° *"
}

sair() {
    separador
    echo "Chao chao chao..."
    exit 0
}

comprobar() {
    separador
    read -p "Dime o nome de usuario que desexas comprobar: " usuario
    if id "$usuario" &>/dev/null; then
        separador
        echo "O usuario $usuario existe no sistema."
    else
        separador
        echo "O usuario $usuario non existe no sistema."
    fi
}

engadir() {
    separador
    read -p "Introduce o nome de usuario que desexas engadir ao sistema: " usuario
    if id "$usuario" &>/dev/null; then
        separador
        echo "O usuario $usuario xa existe no sistema."
    else
        separador
        useradd -m "$usuario"
        echo "O usuario $usuario foi engadido ao sistema."
    fi
}

eliminar() {
    separador
    read -p "Introduce o nome de usuario que desexas eliminar do sistema: " usuario
    if [[ "$usuario" == "root" ]]; then
        echo "Non se pode eliminar o usuario root."
    elif who | grep -q "$usuario"; then
        echo "O usuario está actualmente conectado."
    elif id "$usuario" &>/dev/null; then
        userdel -r "$usuario"
        echo "O usuario $usuario foi eliminado do sistema."
    else
        echo "O usuario $usuario non existe no sistema."
    fi
}

listar() {
    separador
    echo "Usuarios do sistema:"
    cut -d: -f1 /etc/passwd
    separador
}

axuda() {
    separador
    echo "Axuda:"
    echo "Este programa permite administrar usuarios no sistema mediante as seguintes opcións:"
    echo "  0 - Fin: Saír do programa."
    echo "  1 - Listar usuarios: Mostra os nomes dos usuarios no sistema."
    echo "  2 - Comprobar usuario: Comproba se un usuario existe no sistema."
    echo "  3 - Engadir usuario: Engade un novo usuario ao sistema (se non existe)."
    echo "  4 - Eliminar usuario: Elimina un usuario do sistema (se non é root e non está conectado)."
    echo "  5 - Axuda: Mostra esta mensaxe de axuda."
    read -n1 -s -p "Pulsa unha tecla para continuar..."
    echo
    separador
}

while true; do
    programa_principal
done
