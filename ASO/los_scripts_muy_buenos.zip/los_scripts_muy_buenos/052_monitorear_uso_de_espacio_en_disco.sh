#!/bin/bash

# Definir umbral de espacio (en porcentaje)
THRESHOLD=90

# Comprobar el uso de espacio en disco
df -h | awk '{ if ($5+0 >= '$THRESHOLD') print "Alerta: " $1 " está usando " $5 " del disco." }'
