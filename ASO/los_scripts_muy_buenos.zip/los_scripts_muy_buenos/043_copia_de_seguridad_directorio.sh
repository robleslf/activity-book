#!/bin/bash

# Directorio a respaldar
directorio_a_respaldo="$1"

# Verificar si el directorio fue proporcionado
if [ -z "$directorio_a_respaldo" ]; then
    echo "Por favor, proporciona el directorio a respaldar."
    exit 1
fi

# Nombre del archivo de respaldo
fecha=$(date '+%Y-%m-%d_%H-%M-%S')
respaldo="respaldo_${fecha}.tar.gz"

# Crear la copia de seguridad
tar -czf "$respaldo" "$directorio_a_respaldo"
echo "Copia de seguridad realizada: $respaldo"
