#!/bin/bash

# Función para mostrar la lista de usuarios conectados actualmente
usuarios_conectados() {
    echo "Usuarios conectados actualmente:"
    who
}

# Función para mostrar el espacio en disco disponible
espazo_en_disco() {
    echo "Espacio en disco disponible:"
    df -h
}

# Programa principal
while true; do
    # Mostrar el menú
    echo "Menú:"
    echo "  0 - Fin"
    echo "  1 - Mostrar a lista de usuarios conectados"
    echo "  2 - Mostrar o espazo en disco"
    echo -n "A súa opción: "
    read opcion

    # Procesar la opción del usuario
    case $opcion in
        0)
            echo "Finalizando o programa. Ata logo!"
            break
            ;;
        1)
            usuarios_conectados
            ;;
        2)
            espazo_en_disco
            ;;
        *)
            echo "Opción non válida, por favor intente de novo."
            ;;
    esac
    echo # Espacio para mejorar la legibilidad
done
