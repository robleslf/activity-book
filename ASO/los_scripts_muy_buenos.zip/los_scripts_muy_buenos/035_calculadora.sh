#!/bin/bash

pedir_numero() {
	interruptor=1
	while [[ $interruptor -eq 1 ]]; do
		read -p "Dime el $1 numero: " numero
		interruptor=$(comproba $numero)
	done

	echo $numero
}

comproba() {
	if [[ $1 =~ ^[+-]?[0-9]+$ ]]; then
		echo "0"
	else
		echo "1"
	fi
}

sumar() {
	echo "$1 + $2" | bc
}

restar() {
	echo "$1 - $2" | bc
}

multiplicar() {
	echo "$1 * $2" | bc
}

dividir() {
	if [[ $2 -eq 0 ]]; then
		echo "No se puede dividir entre 0"
	else
		echo "scale=2; $1 / $2" | bc

	fi
}

operar() {
	clear
	num1=$(pedir_numero "primer")
	clear
	num2=$(pedir_numero "segundo")
	clear
	echo "Elija una operacion: "
	echo "+"
	echo "-"
	echo "x"
	echo "/"
	echo "q (salir)"
	read -p "Operación: " operacion
	clear
	case $operacion in
		"+") echo "El resultado es $(sumar $num1 $num2)"; read enter
		;;
		"-") echo "El resultado es $(restar $num1 $num2)"; read enter
		;;
		"x"|"*") echo "El resultado es $(multiplicar $num1 $num2)"; read enter
		;;
		"/") echo "El resultado es $(dividir $num1 $num2)"; read enter
		;;
		"q"|"quit") exit 0
		;;
		*) echo "Operador no válido."; read enter
		;;
	esac
}


while true; do
	operar
done



