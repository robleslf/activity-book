#!/bin/bash

# Nombre del archivo con la fecha y hora
archivo="archivo_$(date '+%Y-%m-%d_%H-%M-%S').txt"

# Crear el archivo
touch "$archivo"
echo "Archivo creado: $archivo"
