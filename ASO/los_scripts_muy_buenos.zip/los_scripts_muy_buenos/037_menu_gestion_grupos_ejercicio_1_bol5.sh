#!/bin/bash

# Función para mostrar el menú
mostrar_menu() {
    clear
    echo "----------------------------------------"
    echo "            XESTION DE GRUPOS           "
    echo "----------------------------------------"
    echo "   1) Crear grupo(s) por consola"
    echo "   2) Eliminar grupo(s) por consola"
    echo "   3) Crear grupos a partir de ficheiro"
    echo "   4) Eliminar grupos a partir de ficheiro"
    echo "   5) Axuda"
    echo "   6) Saída"
    echo "----------------------------------------"
    echo -n "Seleccione unha opción: "
}

# Función para validar nombres de grupos
validar_grupo() {
    local grupo="$1"
    [[ "$grupo" =~ ^[a-zA-Z0-9_-]+$ ]]  # Permite letras, números, guiones y guiones bajos
}

# Función para verificar si un grupo existe en el sistema
existe_grupo() {
    getent group "$1" > /dev/null 2>&1
}

# Función para crear grupos desde un array
crear_grupos() {
    local grupos=("$@")
    for grupo in "${grupos[@]}"; do
        if validar_grupo "$grupo"; then
            if existe_grupo "$grupo"; then
                echo "O grupo '$grupo' xa existe."
            else
                sudo groupadd "$grupo" && echo "Grupo '$grupo' creado con éxito."
            fi
        else
            echo "Nome do grupo '$grupo' non é válido."
        fi
    done
}

# Función para eliminar grupos desde un array
eliminar_grupos() {
    local grupos=("$@")
    for grupo in "${grupos[@]}"; do
        if validar_grupo "$grupo"; then
            if existe_grupo "$grupo"; then
                sudo groupdel "$grupo" && echo "Grupo '$grupo' eliminado con éxito."
            else
                echo "O grupo '$grupo' non existe."
            fi
        else
            echo "Nome do grupo '$grupo' non é válido."
        fi
    done
}

# Función para procesar grupos desde un fichero
procesar_ficheiro() {
    local ficheiro="$1"
    local accion="$2"  # "crear" ou "eliminar"

    if [[ ! -f "$ficheiro" ]]; then
        echo "Erro: O ficheiro '$ficheiro' non existe."
        return 1
    fi

    local grupos=()
    while IFS= read -r grupo; do
        [[ -n "$grupo" ]] && grupos+=("$grupo")
    done < "$ficheiro"

    if [[ "$accion" == "crear" ]]; then
        crear_grupos "${grupos[@]}"
    elif [[ "$accion" == "eliminar" ]]; then
        eliminar_grupos "${grupos[@]}"
    else
        echo "Acción descoñecida: $accion"
    fi
}

# Función para mostrar a axuda
mostrar_axuda() {
    echo "Axuda:
    1) Crear grupo(s) por consola: Permite crear un ou máis grupos ingresados por teclado.
    2) Eliminar grupo(s) por consola: Permite eliminar un ou máis grupos ingresados por teclado.
    3) Crear grupos a partir de ficheiro: Crea grupos listados nun ficheiro, un por liña.
    4) Eliminar grupos a partir de ficheiro: Elimina grupos listados nun ficheiro, un por liña.
    5) Axuda: Mostra esta información.
    6) Saída: Finaliza o programa."
}

# Programa principal
while true; do
    mostrar_menu
    read opcion

    case "$opcion" in
        1)
            echo -n "Introduce os nomes dos grupos separados por espazo: "
            read -a grupos
            crear_grupos "${grupos[@]}"
            ;;
        2)
            echo -n "Introduce os nomes dos grupos separados por espazo: "
            read -a grupos
            eliminar_grupos "${grupos[@]}"
            ;;
        3)
            echo -n "Introduce o nome do ficheiro cos grupos a crear: "
            read ficheiro
            procesar_ficheiro "$ficheiro" "crear"
            ;;
        4)
            echo -n "Introduce o nome do ficheiro cos grupos a eliminar: "
            read ficheiro
            procesar_ficheiro "$ficheiro" "eliminar"
            ;;
        5)
            mostrar_axuda
            ;;
        6)
            echo "Saíndo do programa. Ata logo!"
            break
            ;;
        *)
            echo "Opción non válida. Por favor, tente de novo."
            ;;
    esac
    echo -n "Prema Enter para continuar..."
    read
done
