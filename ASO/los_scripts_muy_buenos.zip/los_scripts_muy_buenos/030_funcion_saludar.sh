#!/bin/bash

# Definición de la función saudar
saudar() {
    echo "¡Hola, $1! Bienvenido/a."
}

# Solicitar el nombre del usuario
echo -n "Por favor, introduce tu nombre: "
read nombre

# Llamar a la función saudar con el nombre del usuario
saudar "$nombre"
