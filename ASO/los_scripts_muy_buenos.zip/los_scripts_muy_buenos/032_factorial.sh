#!/bin/bash

# Función para comprobar si el número es un entero positivo
comproba() {
    if [[ "$1" =~ ^[+]?[0-9]+$ ]]; then
        return 0  # El número es un entero positivo (con o sin '+')
    else
        echo "Erro: O número debe ser un enteiro positivo."
        return 1  # El número no es válido
    fi
}

# Función recursiva para calcular el factorial
factorial() {
    if [[ "$1" -le 1 ]]; then
        echo 1
    else
        local prev=$(factorial $(( $1 - 1 )))
        echo $(( $1 * prev ))
    fi
}

# Programa principal
echo -n "Introduce un número enteiro positivo: "
read numero

# Eliminar el signo '+' si existe
numero=${numero#+}

# Comprobar si el número es válido
if comproba "$numero"; then
    resultado=$(factorial "$numero")
    echo "O factorial de $numero é: $resultado"
fi
