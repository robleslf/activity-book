#!/bin/bash

# Verificar si el archivo es pasado como argumento
if [ -z "$1" ]; then
    echo "Por favor, proporciona el nombre de un archivo."
    exit 1
fi

# Contar palabras
contador=0
while read -r linea; do
    palabras=$(echo $linea | wc -w)
    contador=$((contador + palabras))
done < "$1"

echo "El archivo '$1' tiene $contador palabras."
