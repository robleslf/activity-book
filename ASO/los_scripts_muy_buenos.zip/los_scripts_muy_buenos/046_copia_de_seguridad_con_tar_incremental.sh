#!/bin/bash

# Definir directorio de origen y destino
SOURCE_DIR="/home/usuario/datos"
BACKUP_DIR="/home/usuario/copia_incremental"
DATE=$(date +%Y-%m-%d_%H-%M-%S)
LAST_BACKUP="$BACKUP_DIR/last_backup"

# Crear directorio de copia de seguridad si no existe
mkdir -p "$BACKUP_DIR"

# Crear la copia de seguridad incremental
tar -czvf "$BACKUP_DIR/backup_incremental_$DATE.tar.gz" -C "$SOURCE_DIR" --listed-incremental="$LAST_BACKUP" .

# Verificar si la copia fue exitosa
if [ $? -eq 0 ]; then
    echo "Copia de seguridad incremental creada exitosamente: $BACKUP_DIR/backup_incremental_$DATE.tar.gz"
else
    echo "Error al crear la copia de seguridad incremental."
fi
